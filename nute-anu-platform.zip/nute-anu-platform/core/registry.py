"""
core/registry.py

Quet thu muc modules/ va nap tat ca manifest.yaml.
Day la co che de UI (vi du sbbs-demo) doc danh sach Smart Box dong,
thay vi hard-code trong js/data.js.

Them module moi = them 1 thu muc + 1 manifest.yaml trong modules/.
Khong can sua file nay.
"""

import yaml
from pathlib import Path

MODULES_DIR = Path(__file__).parent.parent / "modules"
REQUIRED_MANIFEST_FIELDS = ["module_id", "owner_unit", "risk_level", "data_scope"]


class ManifestError(Exception):
    pass


def _validate(manifest: dict, module_dir: str):
    missing = [f for f in REQUIRED_MANIFEST_FIELDS if f not in manifest]
    if missing:
        raise ManifestError(f"Module '{module_dir}': thieu truong bat buoc {missing}")
    if manifest["risk_level"] not in ("low", "medium", "high", "critical"):
        raise ManifestError(f"Module '{module_dir}': risk_level khong hop le")


def nap_tat_ca_module() -> dict:
    """Tra ve dict {module_id: manifest} cho moi module hop le, bo qua _template."""
    modules = {}
    for path in MODULES_DIR.iterdir():
        if not path.is_dir() or path.name.startswith("_"):
            continue
        manifest_path = path / "manifest.yaml"
        if not manifest_path.exists():
            continue
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = yaml.safe_load(f)
        _validate(manifest, path.name)
        modules[manifest["module_id"]] = manifest
    return modules


def lay_module(module_id: str) -> dict:
    modules = nap_tat_ca_module()
    if module_id not in modules:
        raise ManifestError(f"Module khong ton tai hoac chua duoc dang ky: {module_id}")
    return modules[module_id]
