"""
core/data_gateway.py

Cong duy nhat de module doc du lieu va thuc hien hanh dong.
Khong module nao duoc query thang vao mock_data/ hay he thong nghiep vu that.

Thuc thi ba nguyen tac:
  1. Module chi doc duoc field nam trong data_scope.read cua chinh no (muc 4.15a)
  2. Field nam trong data_scope.forbidden bi chan cung, du co trong read
  3. Moi hanh dong (thanh cong hay bi tu choi) deu ghi audit log (muc 4.14g)
"""

import json
from pathlib import Path
from datetime import datetime, timezone

from core import registry, identity, audit_log

MOCK_DATA_DIR = Path(__file__).parent.parent / "mock_data"


class AccessDenied(Exception):
    pass


def _field_khop(field: str, patterns: list) -> bool:
    for p in patterns:
        if p == field or (p.endswith(".*") and field.startswith(p[:-1])):
            return True
    return False


def request_data(module_id: str, fields: list) -> dict:
    manifest = registry.lay_module(module_id)
    scope_read = manifest["data_scope"].get("read", [])
    scope_forbidden = manifest["data_scope"].get("forbidden", [])

    result = {}
    for field in fields:
        allowed = _field_khop(field, scope_read) and not _field_khop(field, scope_forbidden)

        if not allowed:
            audit_log.ghi_log({
                "actor": {"type": "ai_agent", "id": module_id},
                "action": {"type": "request_data", "target": field},
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "authority": {"basis": "manifest.data_scope", "delegation_ref": None},
                "data_source": {"fields": [field], "last_updated": None, "staleness_flag": None},
                "outcome": {"ai_recommendation": None, "human_decision": "denied",
                            "decision_by": "system", "reason_if_different": "outside data_scope"},
            })
            raise AccessDenied(f"Module '{module_id}' khong duoc phep doc truong '{field}'")

        table, _, column = field.partition(".")
        mock_file = MOCK_DATA_DIR / f"{table}.json"
        if not mock_file.exists():
            result[field] = None
            continue
        with open(mock_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        result[field] = {
            "value": data.get(column),
            "last_updated": data.get("_last_updated"),
        }

    audit_log.ghi_log({
        "actor": {"type": "ai_agent", "id": module_id},
        "action": {"type": "request_data", "target": ",".join(fields)},
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "authority": {"basis": "manifest.data_scope", "delegation_ref": None},
        "data_source": {"fields": fields, "last_updated": None, "staleness_flag": False},
        "outcome": {"ai_recommendation": None, "human_decision": "granted",
                    "decision_by": "system", "reason_if_different": None},
    })
    return result


def submit_action(module_id: str, action_name: str, payload: dict, actor_role: str = None) -> dict:
    manifest = registry.lay_module(module_id)
    action_def = next((a for a in manifest.get("actions", []) if a["name"] == action_name), None)
    if action_def is None:
        raise ValueError(f"Module '{module_id}' khong khai bao action '{action_name}'")

    risk = manifest["risk_level"]
    requires_approval = action_def.get("requires_human_approval", True)
    action_key = f"{module_id}.{action_name}.risk:{risk}"

    outcome = {
        "ai_recommendation": payload,
        "human_decision": "pending",
        "decision_by": None,
        "reason_if_different": None,
    }

    if requires_approval:
        if actor_role is None or not identity.co_the_duyet(actor_role, action_key):
            outcome["human_decision"] = "pending"
        else:
            outcome["human_decision"] = "approved"
            outcome["decision_by"] = actor_role
    else:
        outcome["human_decision"] = "approved"
        outcome["decision_by"] = "system"

    log_entry = audit_log.ghi_log({
        "actor": {"type": "ai_agent", "id": module_id},
        "action": {"type": action_name, "target": payload.get("target", "n/a")},
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "authority": {"basis": f"manifest.actions[{action_name}]", "delegation_ref": None},
        "data_source": {"fields": list(payload.keys()), "last_updated": None, "staleness_flag": False},
        "outcome": outcome,
    })
    return log_entry
