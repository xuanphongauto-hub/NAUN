"""
core/identity.py

Quan ly vai tro va quyen han o muc toi thieu (mock).
Production that su se anh xa vao Entra ID groups thay vi file nay,
nhung interface (ham co_the_duyet, lay_vai_tro) se giu nguyen -
day la ly do goi la "kien truc doc lap voi mo hinh".
"""

import yaml
from pathlib import Path

ROLES_FILE = Path(__file__).parent / "roles.yaml"


def _tai_vai_tro():
    with open(ROLES_FILE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)["roles"]


def lay_vai_tro(role_id: str) -> dict:
    roles = _tai_vai_tro()
    if role_id not in roles:
        raise ValueError(f"Vai tro khong ton tai: {role_id}")
    return roles[role_id]


def co_the_doc(role_id: str, field: str) -> bool:
    """Kiem tra vai tro co duoc doc truong du lieu nay khong."""
    role = lay_vai_tro(role_id)
    allowed = role.get("can_read", [])
    for pattern in allowed:
        if pattern == "*":
            return True
        if pattern.endswith(".*") and field.startswith(pattern[:-1]):
            return True
        if pattern == field:
            return True
    return False


def co_the_duyet(role_id: str, action_key: str) -> bool:
    """
    action_key co dang: "<module_id>.<action_name>.risk:<level>"
    Vi du: "training-agent.recommend_learning_path.risk:medium"
    """
    role = lay_vai_tro(role_id)
    allowed = role.get("can_approve", [])
    module_action, _, risk_part = action_key.rpartition(".")
    for pattern in allowed:
        if pattern == "*":
            return True
        if pattern == action_key:
            return True
        if pattern == module_action:
            # pattern la ten module.hanh_dong cu the (khong kem risk) -> khop moi muc rui ro
            return True
        if pattern.startswith("*.") and pattern[2:] == risk_part:
            return True
    return False
