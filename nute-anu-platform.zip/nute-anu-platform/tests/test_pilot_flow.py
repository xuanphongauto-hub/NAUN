"""
tests/test_pilot_flow.py

Test nay MO PHONG toan bo luong: module xin du lieu -> core kiem tra
quyen -> module de xuat hanh dong -> cho nguoi co tham quyen duyet ->
audit log ghi du 6 truong.

Chay:  python -m pytest tests/ -v

Day la cach kiem chung "kien truc dung ve mat logic" ma khong can
ket noi Entra ID / SharePoint that.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from core import data_gateway, audit_log


# Don sach log truoc va sau moi test de cac test doc lap voi nhau
@pytest.fixture(autouse=True)
def clean_log():
    if audit_log.LOG_FILE.exists():
        audit_log.LOG_FILE.unlink()
    yield
    if audit_log.LOG_FILE.exists():
        audit_log.LOG_FILE.unlink()


def test_de_xuat_lo_trinh_tao_ket_qua_pending_khi_khong_co_nguoi_duyet():
    from modules.training_agent import agent
    ket_qua = agent.de_xuat_lo_trinh("sv001", actor_role=None)
    assert ket_qua["outcome"]["human_decision"] == "pending"


def test_de_xuat_lo_trinh_duoc_duyet_khi_co_co_van_hoc_tap():
    from modules.training_agent import agent
    ket_qua = agent.de_xuat_lo_trinh("sv001", actor_role="academic_advisor")
    assert ket_qua["outcome"]["human_decision"] == "approved"
    assert ket_qua["outcome"]["decision_by"] == "academic_advisor"


def test_module_khong_the_doc_du_lieu_ngoai_pham_vi():
    from modules.training_agent import agent
    with pytest.raises(data_gateway.AccessDenied):
        agent.thu_vuot_quyen()


def test_audit_log_tu_choi_ghi_neu_thieu_truong_bat_buoc():
    with pytest.raises(audit_log.AuditLogError):
        audit_log.ghi_log({"actor": {"type": "ai_agent", "id": "x"}})  # thieu 5 truong con lai


def test_moi_hanh_dong_deu_co_dau_vet_trong_audit_log():
    from modules.training_agent import agent
    agent.de_xuat_lo_trinh("sv002", actor_role="academic_advisor")
    logs = audit_log.doc_log()
    assert len(logs) >= 1
    for entry in logs:
        for field in audit_log.REQUIRED_FIELDS:
            assert field in entry
