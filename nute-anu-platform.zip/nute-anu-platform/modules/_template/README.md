# Huong dan them Smart Box / tac nhan moi

1. Copy thu muc `_template/` sang `modules/<ten-module-cua-ban>/`
2. Sua `manifest.yaml`: dien `module_id`, `owner_unit`, `risk_level`, `data_scope`
3. Viet code xu ly trong file `agent.py` (hoac ten khac) trong cung thu muc -
   goi du lieu qua `core.data_gateway.request_data()`, KHONG doc thang mock_data/
4. Tao Pull Request tren GitHub. GitHub Action se tu dong kiem tra manifest
   hop le (script/validate_manifest.py) truoc khi cho merge
5. Tuy risk_level, PR se can nguoi phu hop duyet noi dung:
   - low: Truong don vi
   - medium/high: CAIO
   - critical: Hieu truong

Khong sua bat ky file nao trong `core/` khi them module moi.
