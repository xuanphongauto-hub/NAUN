"""
scripts/validate_manifest.py

Kiem tra tu dong (Gate G0/G1) truoc khi mot Pull Request them module moi
duoc xem xet noi dung. Chay thu cong:

    python scripts/validate_manifest.py

Hoac duoc goi tu .github/workflows/validate.yml khi co PR.
Thoat voi ma loi khac 0 neu co module nao khong hop le -> CI se bao do.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from core import registry


def main():
    try:
        modules = registry.nap_tat_ca_module()
    except registry.ManifestError as e:
        print(f"[LOI] {e}")
        sys.exit(1)

    if not modules:
        print("[CANH BAO] Khong tim thay module nao trong modules/")
        sys.exit(0)

    print(f"Da kiem tra {len(modules)} module hop le:\n")
    for module_id, m in modules.items():
        print(f"  - {module_id}  (owner: {m['owner_unit']}, risk: {m['risk_level']}, status: {m.get('status')})")

    print("\nTat ca manifest hop le.")
    sys.exit(0)


if __name__ == "__main__":
    main()
