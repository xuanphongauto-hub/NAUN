"""
modules/training-agent/agent.py

Vi du thuc thi mot module: Tac nhan Dao tao.
Luu y: module nay KHONG import mock_data truc tiep, chi goi qua core.data_gateway.
Day la diem quan trong nhat de kiem chung kien truc dung khi test.
"""

from core import data_gateway

MODULE_ID = "training-agent"


def de_xuat_lo_trinh(student_id: str, actor_role: str = None) -> dict:
    """
    Doc tien do hoc tap va chuan dau ra, de xuat mo-dun tiep theo.
    Vi risk_level = medium va requires_human_approval = true (xem manifest.yaml),
    ket qua se o trang thai "pending" cho den khi actor_role du quyen duyet.
    """
    du_lieu = data_gateway.request_data(
        MODULE_ID,
        ["training.course_progress", "training.curriculum_standards"],
    )

    # Logic khuyen nghi don gian cho ban demo - production se phuc tap hon
    tien_do = du_lieu["training.course_progress"]["value"]
    de_xuat = "module_nang_cao" if tien_do and tien_do >= 80 else "module_on_tap"

    ket_qua = data_gateway.submit_action(
        MODULE_ID,
        "recommend_learning_path",
        payload={"target": student_id, "de_xuat": de_xuat, "tien_do": tien_do},
        actor_role=actor_role,
    )
    return ket_qua


def thu_vuot_quyen():
    """
    Ham nay CO Y de goi thu truong khong nam trong data_scope (finance.*)
    de chung minh core.data_gateway chan dung - dung trong test, khong dung
    trong luong nghiep vu that.
    """
    return data_gateway.request_data(MODULE_ID, ["finance.budget_total"])
