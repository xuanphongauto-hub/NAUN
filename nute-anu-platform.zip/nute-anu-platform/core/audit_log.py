"""
core/audit_log.py

Thuc thi nguyen tac "6 cau hoi" (muc 4.14g cua De an ANU):
Ai thuc hien - Thuc hien viec gi - Khi nao - Theo tham quyen nao -
Dua tren du lieu nao - Ket qua ra sao.

Neu thieu bat ky truong nao, ham ghi_log() se tu choi ghi va nem loi -
dong nghia hanh dong do khong duoc coi la hop le trong he thong.
"""

import json
from pathlib import Path
from datetime import datetime, timezone

LOG_FILE = Path(__file__).parent.parent / "audit_log.jsonl"

REQUIRED_FIELDS = ["actor", "action", "timestamp", "authority", "data_source", "outcome"]


class AuditLogError(Exception):
    pass


def ghi_log(entry: dict) -> dict:
    missing = [f for f in REQUIRED_FIELDS if f not in entry]
    if missing:
        raise AuditLogError(
            f"Tu choi ghi log - thieu truong bat buoc: {missing}. "
            f"Hanh dong khong duoc coi la hop le neu thieu du 6 thong tin."
        )

    entry = dict(entry)
    entry["timestamp"] = entry.get("timestamp") or datetime.now(timezone.utc).isoformat()

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    return entry


def doc_log() -> list:
    if not LOG_FILE.exists():
        return []
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]
